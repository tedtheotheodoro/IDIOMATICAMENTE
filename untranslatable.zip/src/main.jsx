import React from 'react'
import ReactDOM from 'react-dom/client'
import Untranslatable from './Untranslatable'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Untranslatable />
  </React.StrictMode>,
)